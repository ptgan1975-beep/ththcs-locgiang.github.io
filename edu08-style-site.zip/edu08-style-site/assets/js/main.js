
document.addEventListener('DOMContentLoaded', function(){
  const slides = document.querySelectorAll('.slider img');
  let idx = 0;
  if(!slides || slides.length===0) return;
  setInterval(()=>{
    slides.forEach((s,i)=> s.style.display = (i===idx?'block':'none'));
    idx = (idx+1) % slides.length;
  }, 4000);
});
